# variables for testing
x, y, z = 4, 5, 4

# replace the string literal with the relational expression
#print( y * x - z  != 4%4 +15)
word1 = "!BBBBB"
word2 = "B"
print(word1 or word2)
