# define variables
a, b, c = 5, 2, 0

# print output
print("Line 5:", a == b)
print("Line 6:", a != b)
print("Line 7:", ((a > c) or ((b / c) == 1)))
#print("Line 8:", ((a > c) and ((b / c) == 1)))
print("Line 9:", (c <= b) and (b <= a))
