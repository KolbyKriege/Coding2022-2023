print("Go!")
