Print congratulatory message
print()
print()
print()