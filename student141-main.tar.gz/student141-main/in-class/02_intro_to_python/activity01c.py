name = input("What is your name? ")
print("Your name is", name)
