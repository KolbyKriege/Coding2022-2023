"""
In-Class Exercise and Demo: Writing Files

File Name: recorde.py
Course:    CPTR 141
"""

# write your code here
import csv
repeat = True
# while repeat == True:
#     student_id = input("Enter student ID ('done' to quit): ")
#     if student_id =='done':
#         break
#     student_name = input("Enter student name: ")
#     student_year = input("Enter expected graduation year: ")
#     print()
#     with open("students.txt",'w') as temp:
#         temp.write("ID: {}\n".format(student_id))
#         temp.write("Name: {}\n".format(student_name))
#         temp.write("Year: {}\n".format(student_year))


with open("students.csv",'w') as temp:
    temp.write("Student ID,Name,Year\n")
while repeat == True:
    record = []
    record.append(input("Enter student ID ('done' to quit): "))
    if record[0] =='done':
        break
    record.append( input("Enter student name: "))
    record.append( input("Enter expected graduation year: "))
    print()
    
    with open("students.csv",'a') as temp:
        student_write = csv.writer(temp)
        student_write.writerow(record)