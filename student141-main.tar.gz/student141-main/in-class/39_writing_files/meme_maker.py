"""
In-Class Exercise and Demo: Manipulating Images

Note: Install the pillow library using the command:

      pip3 install --user pillow

File Name: meme_maker.py
Course:    CPTR 141
"""

# write code here

