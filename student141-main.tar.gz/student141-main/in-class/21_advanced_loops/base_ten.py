"""
In-Class Exercises: Print the base ten expansion of a number

File Name: base_ten.py
Course:    CPTR 141
"""

num = input("Enter a Number: ")
