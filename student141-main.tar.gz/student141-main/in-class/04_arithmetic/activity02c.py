a = float(input("First number: "))
b = float(input("Second number: "))
answer = a / b
print("Quotient: ", a, "/", b, "=", answer)
