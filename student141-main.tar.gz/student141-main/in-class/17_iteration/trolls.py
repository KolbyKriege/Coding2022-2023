"""
In-Class Exercise: Using Containers to Store Prices and More

File Name: trolls.py
Course:    CPTR 141
"""

trolls = {}

# convert to a sentinal-controlled loop
add_more = 'y'
while add_more == 'y':
    store = input("Enter Store {}: ".format(len(trolls)+1))
    price = float(input("Enter Price {}: ".format(len(trolls)+1 )))
    trolls[store] = price
    add_more = input("Enter another store [y/n]?")
    print()


lowest_price_dict = min(trolls.values())
lowest_store_dict = min(trolls, key=trolls.get)
print("Lowest price is ${:.2f} at {}".format(
    lowest_price_dict, lowest_store_dict))
