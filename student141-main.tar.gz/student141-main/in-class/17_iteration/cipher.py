"""
In-Class Exercise:  Use code point to transform characters

File Name: cipher.py
Course:    CPTR 141
"""

# Collect the secret
repeat = 'y'
while repeat ==  'y':
    secret = input("Enter a secret: ")

# Collect the Caesar Cipher alphabet shift
    offset = int(input("Enter cipher shift: "))

# YOUR CODE GOES HERE
    encoded = ""
    i = 0
    while i < len(secret):
        encoded = encoded +  chr(ord(secret[i]) + offset)
        i += 1

    print("The encoded text is: {}".format(encoded))
    repeat = input("Would you like to incode antother sceret [y/n]?")
