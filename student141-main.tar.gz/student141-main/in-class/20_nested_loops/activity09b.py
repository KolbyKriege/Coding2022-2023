cols = 7
rows = 5

for i in range(cols):
    for j in range(rows):
        print(j+1, end=" ")
    print()
