name = input("What is your name? ")
for i in range(5):
    for j in range(3):
        print(name, end=" ")
    print()
