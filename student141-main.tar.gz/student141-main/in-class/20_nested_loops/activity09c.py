num_rows = 6

print(type(num_rows))
for j in range(1, num_rows, 1):
    for i in range(1, j + 1):
        print(i, end=" ")
    print()





