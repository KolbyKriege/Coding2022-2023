import sys

for i in range(5):
    print("Number: {:d}".format(i))
print("Done!", file=sys.stderr)