class_name = "Fundamentals of Programming I"
print(class_name)
print(class_name[0])
print(class_name[0:12])
print(class_name[-1])
print(class_name[16:])
