digits = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
fruits = ["apple", "banana", "cantelope", "pear", "orange"]
students = ["Jones", 3.4, "Hernandez", 3.6]
print(fruits[0])
