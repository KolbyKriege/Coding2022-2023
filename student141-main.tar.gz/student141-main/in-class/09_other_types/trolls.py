"""
In-Class Exercise: Using Containers to Store Prices and More

File Name: trolls.py
Course:    CPTR 141
"""

stores = 
prices = 

stores1 = input("Enter Store 1: "))
price1 = float(input("Enter Price 1: ")))

stores2 = (input("Enter Store 2: "))
prices2 = (float(input("Enter Price 2: ")))

stores3 = (input("Enter Store 3: "))
prices3 = (float(input("Enter Price 3: ")))

stores_price{}
stores_price
lowest_price = min(prices)
lowest_index = prices.index(lowest_price)
print("Lowest price is ${:.2f} at {}".format(
    lowest_price, stores[lowest_index]))
