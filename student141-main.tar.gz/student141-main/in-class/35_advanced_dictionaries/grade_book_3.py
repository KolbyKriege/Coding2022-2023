import grades_3


def average(grades):
    '''
    Pre: grades is a list of grades
    Post: returns the average of all entries in the 1-dimensional list
    '''
    # TODO Copy your code from previous work
    return sum(grades)/len(grades)


def minimum(grades):
    '''
    Pre: grades is a 1-dimensional list of grades
    Post: returns the minimum of the list
    '''
    # TODO Finish this function
    return min(grades)


def maximum(grades):
    '''
    Pre: grades is a 1-dimensional list of grades
    Post: returns the maximum of the list
    '''
    # TODO Finish this function
    return max(grades)


#print("{:^10s} | {:^4s} | {:^7s} | {:^7s} | {:^7s}".format("Name", "ID", "Average", "Max", "Min"))
# TODO Finish the table
for x in grades_3.grades:
    studnet_id =  grades_3.grades[x]['id']
    print("{:^10s} | {:^4s} | {:^7s} | {:^7s} | {:^7s}".format(x, , ), ), )