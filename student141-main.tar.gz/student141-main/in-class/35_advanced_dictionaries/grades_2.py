# TODO Combine 'names' and 'grades' into a single 'grades' dictionary,
# with names as keys and lists of grades as values

# class roster
# names = ["Carlos", "Elizabeth", ]

# define a 2D array of scores
# grades = [
#     [73, 62, 42, 59],  # grades for student 1
#     [91, 97, 83, 81],  # grades for student 2
#     [78, 82, 91, 90],  # grades for student 3
#     [83, 74, 69, 72],  # grades for student 4
#     [95, 74, 83, 89],  # grades for student 5
# ]
grades = {
    "Carlos" : [73, 62, 42, 59],
    "Elizabeth" : [91, 97, 83, 81],
    "Kolby" : [78, 82, 91, 90],
    "Josh" : [83, 74, 69, 72],
    "Adin" : [95, 74, 83, 89]
    }