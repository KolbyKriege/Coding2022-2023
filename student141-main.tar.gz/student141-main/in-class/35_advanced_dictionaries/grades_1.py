# class roster
names = ["Carlos", "Elizabeth", "Kolby", "Josh", "Adin"]

# define a 2D array of scores
grades = [
    [73, 62, 42, 59],  # grades for student 1
    [91, 97, 83, 81],  # grades for student 2
    [78, 82, 91, 90],  # grades for student 3
    [83, 74, 69, 72],  # grades for student 4
    [95, 74, 83, 89],  # grades for student 5
]
