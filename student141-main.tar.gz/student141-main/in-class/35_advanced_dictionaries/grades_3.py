# TODO Combine 'names', 'ids', and 'grades' into a dictionary
# of dictionaries, as shown in the slides

# class roster
# names = ["Carlos", "Elizabeth", ]
# ids = [14, 88, 16, 44, 50]

# define a 2D array of scores
# scores = [
#     [73, 62, 42, 59],
#     [91, 97, 83, 81],
#     [78, 82, 91, 90],
#     [83, 74, 69, 72],
#     [95, 74, 83, 89],
# ]

grades = {
    "Carlos" : {
        'id': 14,
        'scores' : [73, 62, 42, 59]
    },
    "Elizabeth" : {
        'id' : 88,
        'scores' : [91, 97, 83, 81]
    },
    "Kolby": {
        'id': 16,
        'scores' : [78, 82, 91, 90]
    },
    'Josh' : {
        'id': 44,
        'scores' : [83, 74, 69, 72]
    },
    'Adain' : {
        'id' : 50,
        'scores' : [95, 74, 83, 89]
    }
    
}
