"""
In-Class Exercise and Demo: Reading Files

File Name: min_max.py
Course:    CPTR 141

Assignment:
  1. Prompt user for an input file name.
  2. Print the smallest number, largest number, and total number of integers.
  * Intermission
  3. Add error checking to make sure file exists. 
"""

numeric_list = []

# prompt for input file

# read file into a list

# process file input into numbers

# print output to console
print("Smallest: {}".format(min(numeric_list)))
print("Largest: {}".format(max(numeric_list)))
print("Line count: {}".format(len(lines)))
