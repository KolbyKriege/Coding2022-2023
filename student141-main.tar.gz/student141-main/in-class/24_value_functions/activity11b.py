import random

# Print celebratory rocket
def print_rocket():
    print("Blast-off!")
    print(" /^\\")
    print("/***\\")
    print("|***|")
    print("|***|")
    print("|#|#|")

# give problem and check answer
def give_problem(num1,num2):
    correct_ans = num1 + num2
    student_ans = int(input(
      "{} + {} = ".format(
          num1, num2
    )))
    return(correct_ans,student_ans)

num_correct = 0

for i in range(0,5): 
    num1 = random.randint(1,10)
    num2 = random.randint(1,10)
    if give_problem(num1,num2):
        print("Correct!")
        num_correct += 1
    else:
        print("Incorrect!")
        print("It is {}".format(
          num1 + num2
        ))

if num_correct == 5:
    print_rocket()
else:
    print("{} of 5 correct".format(
        num_correct
    ))
