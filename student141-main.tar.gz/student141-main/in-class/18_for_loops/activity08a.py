name = input("Enter your name: ")
for i in range(10):
    print(name)
print("Nice to meet you!")
