pets = ["Fido", "Rex", "Spot", "Snowball"]
ages = [4, 6, 12, 9]

for x in pets:
    print(x, end=" ")
