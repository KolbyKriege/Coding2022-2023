total = 0
for i in range(5):
    number = int(input("Enter a number: "))
    total += number

print("The total is: {}".format(total))
