a = 0


def my_func(b=4):
    c = 5
    print("Value: {}".format("OUTPUT 1"))


def main():
    d = 5
    if d > 2:
        print("Value: {}".format("OUTPUT 2"))
        e = 3
        if e < 10:
            f = 7
            print("Value: {}".format("OUTPUT 3"))
    print("Value: {}".format("OUTPUT 4"))
    my_func()
    print(f)

main()
