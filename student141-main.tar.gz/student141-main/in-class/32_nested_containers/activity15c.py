gradebook = {
    "Samantha": {
        "objectives": {
            "one": {
                "homework": 10,
                "quiz": 0.95
            },
            "two": {
                "homework": 13,
                "quiz": 0.9
            },
            "three": {
                "homework": 11,
                "quiz": 1
            }
        },
        "projects": ["E", "M"],
        "participation": {
            "reading": [1, 1, 1, 1, 0, 1, 1],
            "pogil": [1, 1, 1, 1, 1, 1, 1, 1, 1]
        }
    }
}
#gradebook['Samantha']['objectives']['three']['homework'] = 9
#print(gradebook)
total = 0
for i in gradebook['Samantha']['objectives']:
    total += gradebook['Samantha']['objectives'][i]['homework']
print(total)
