crew = {
    "Captain": {
        "first name": "James",
        "last name": "Kirk",
        "rank": "Captain",
        "email": "capt.kirk@enterprise.com",
    },
    "First Officer": {
        "first name": "S'chn",
        "last name": "Spock",
        "rank": "Commander",
        "email": "mr.logical@enterprise.com",
    },
}
