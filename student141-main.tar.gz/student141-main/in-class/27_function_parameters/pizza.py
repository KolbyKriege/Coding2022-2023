def order_pizza(crust= "", sauce="tomato", *toppings):
    print("Pizza with {} crust and {} sauce ".format(
        crust,sauce,),end=" ")
    if len(toppings)> 0:
        print("topped with",end=" ")
        for i in range(len(toppings)):
            print((toppings))
            i = i


order_pizza("thick", "tomato", "mushrooms")
order_pizza("thick", "tomato", "mushrooms", "pineapple")
order_pizza("thin", "garlic")
