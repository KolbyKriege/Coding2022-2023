""" 
In-Class Exercise:  A "hello world" program.

File Name: hello.py
Name:      ?
Course:    CPTR 141
"""

# print out some text (replace the question mark with your name)
print("Hello World! My name is ? and this may be my first program in CPTR 141!")

test = 'World'
test1 = 'Hello'
test2 = not('W' in test)
print(test2)