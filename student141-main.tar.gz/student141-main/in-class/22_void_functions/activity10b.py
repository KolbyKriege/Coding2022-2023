import math


def print_area(radius):
    area = math.pi * (radius ** 2)
    print("The area of a circle of radius {} is {:.2f}".format(radius, area))


# write main part of the program here
print_area(12)