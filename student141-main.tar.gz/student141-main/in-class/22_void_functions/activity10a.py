# function definition
def print_message():
    print("Welcome to Python.")
    print("Learn the power of functions!")

# function definition
def main():
    print("Hello Programmer...")
    print_message()               # function call

main()                            # function call