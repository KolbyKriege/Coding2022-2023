"""
In-Class Demonstration:  Prompt for two numbers and display their sum

File Name: first_example.py
Course:    CPTR 141
"""

# prompt and save nfrist number
num1 = int(input("Enter your frist  Integer:"))

# prompt and save second number
num2 = int(input("Enter your second Integer:"))

# print sum of frist and second numbers
print("The Sum is", num1, '+', num2, '=', num1+num2)
