"""
In-Class Exercise: Using Containers to Store Prices and More

File Name: trolls.py
Course:    CPTR 141
"""

# existing dictionary
price_dict = {
    "Target": 12.50,
    "Walmart": 11.95,
    "Inland Octopus": 14.50
}

# get store and check if it is in dictionary
store = input("Enter Store: ")

if store in price_dict.keys():

    # get discount
    discount = float(input("Enter Discount Percent: ")) / 100

    # handle case when approximately equal to 1/3rd
    continue_flag = True
    if (((1/3) - 0.1)<=discount<= ((1/3) + 0.1)):
        answer = input("Exaclty 1/3rd --- are you sure: ")
        if answer[0].lower() == 'y':
            continue_flag = False

    # change price and print result
    if continue_flag:
        price_dict[store] = price_dict[store] *(1 - discount)
        print("Price at {} is now at ${:0.2}.").__format__(store, price_dict[store])
        # if store is not in dictionary, print error
else:
    print("That is not a store in this data please try again")
# indicate if dictionary changed
if price_dict == {"Target": 12.50,"Walmart": 11.95,"Inland Octopus": 14.50}:
    print("Price dictionary was not changed")
else:
    print("Price dictionary was changed.")
