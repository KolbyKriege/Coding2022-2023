"""
In-Class Demonstration: Inspect type and id of objects

File Name: inspect_objects.py
Course:    CPTR 141
"""


x = "Hello"
print(type(x), id(x))
x = 1
print(type(x), id(x))
x = 5.3
print(type(x), id(x))
x = 4.9
print(type(x), id(x))
