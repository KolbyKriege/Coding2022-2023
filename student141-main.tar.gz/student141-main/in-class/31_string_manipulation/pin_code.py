"""
In-Class Exercise:  Check to see if a user-entered PIN code is valid
                    (four characters long, contains only digits).

File Name: pin_code.py
Course:    CPTR 141
"""


def valid_pin(pin_code):
    if len(pin_code) != 4:
        return False
    elif not(pin_code.isdigit()):
        return False
    else:
        return True


# collect user input
pin_code = input("Please enter a four digit PIN code: ")

# print out results
if valid_pin(pin_code):
    print("PIN code valid")
else:
    print("ERROR: PIN code not valid")
