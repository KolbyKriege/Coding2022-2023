number = int(input("Enter Number: "))
name = input("Enter Name: ")

for i in range(number):
    print(name)
