def main():
    user_file = input()
    sports_list = open(user_file)
    for index in range(1,16):
        sp = sports_list.readline()
        print("{}. {}".format(index,sp))


main()
