file_name = input("Enter a file name to sum: ")
numbers = open(file_name)


total = 0
for num in numbers:
    num = num.rstrip()
    if num.isnumeric():
        total += int(num)

print("The sum of the numbers in {} is {}.".format(file_name, total))
