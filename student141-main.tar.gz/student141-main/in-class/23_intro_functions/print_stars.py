"""
In-Class Example: Working with Functions

File Name: sprint_stars.py
Course:    CPTR 141
"""

# original function
def print_stars(n):
    for i in range(n):
        print("*", end="")
    print()


# Test your functions in the main program
print_stars(2 + 3)
