my_var = 1

def my_func():
    global my_var
    my_var = 2
    print(my_var)

my_func()
print(my_var)