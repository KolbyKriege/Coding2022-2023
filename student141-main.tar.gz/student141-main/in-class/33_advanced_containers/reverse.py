# TODO add code to reverse a string of the first command line argument
import sys
str_len = (len(sys.argv))
for i in range(str_len):
    print(sys.argv[i][str_len-(i+1)],end='')
# for arg in sys.argv:
#     print(arg)