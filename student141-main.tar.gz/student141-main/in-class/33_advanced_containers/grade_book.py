"""
In-Class Exercise and Demo: Building a Gradebook

File Name: grade_book.py
Course:    CPTR 141
"""

# define a 2D array of scores
grades = [
    [73, 62, 42, 59],  # grades for student 1
    [91, 97, 83, 81],  # grades for student 2
    [78, 82, 91, 90],  # grades for student 3
    [83, 74, 69, 72],  # grades for student 4
    [95, 74, 83, 89],  # grades for student 5
]

def average(grade):
    return sum(grade)/len(grade)

# Find and display the lowest score for each student
print("Lowest Scores")
for i in range(len(grades)):
    for score in grades[i]:
        lowest_score = min(grades[i])
    print("  Student {:d}: {:d}".format(i+1, lowest_score))


# Find and display the highest overall score
maxium = 0

for row in range(len(grades)):
    for score in grades[row]:
        if score >= maxium:
            maxium = max(grades[row])
print("Highest Overall Score: {}".format(maxium))

print("The average {:02f}".format(average(grades[1])))