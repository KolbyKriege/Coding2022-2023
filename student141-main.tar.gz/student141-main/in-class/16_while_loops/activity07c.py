countdown = 100
while countdown > 0:
    print(countdown)
