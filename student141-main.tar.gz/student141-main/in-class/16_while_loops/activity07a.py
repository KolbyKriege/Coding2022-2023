# get a person's name
name = input("Enter your name: ")

# print the name ten times
x = 1
while x < 10:
    print(name)
    x = x + 1

print("Done!")
