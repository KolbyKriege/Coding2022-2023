def sum(a, b=0, c=0, d=0):
    return a + b + c + d


print("Test One:", sum(1, 2, 3, 4))
print("Test Two:", sum(1, 2, 3))
print("Test Three:", sum(1, 2))
