"""
In-Class Exercise:  This program has the user guess a random number.

File Name: guess.py
Course:    CPTR 141
"""
import random
# pick a random number between 1 and 10
#random.seed(456)
random1 = random.randint(1, 10)
# prompt for the user guesses
print("I am thinking of a number bwtween 1 - 10")
guess1 = int(input("What is your guess: "))
guess2 = int(input("What is your second guess: "))
guess3 = int(input("What is your thrid guess: "))
# set a flag based on comparing the guesses with our number
sucesss = False
if guess1 == random1:
    sucesss = True
if guess2 == random1:
    sucesss = True
if guess3 == random1:
    sucesss = True

    # respond to the user
    if sucesss:
        print("\nYou have guess corretly YAY", end="")
print(" The correct number was:",random1)