num_credits = 194
major_GPA = 2.9
overall_GPA = 2.1
if "missing Boolean expression":
    print("Congratulations!")
    print("You seem to meet the criteria for graduation.")
else:
    print("Sorry!")
    print("You do not meet all the criteria for graduation.")
