grade = int(input("Enger your grade: "))
if grade >= 90:
    print("Very Good!")
else:
    if grade >= 60:
        print("Satisfactory.")
    else:
        print("Could be better.")
