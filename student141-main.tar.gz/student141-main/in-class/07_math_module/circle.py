"""
In-Class Exercise:  Compute the circumference of a circle for a given radius

File Name: circle.py
Course:    CPTR 141
"""
import math
# Calculate circumference of a circle
radius = float(input("Enter the radius: "))
circum1 = 2 * radius * math.pi
print("The circumference is", circum1)
print(" The area is", math.pi * math.pow(radius, 2))
# Given the area of a circle, calculate the radius
area = float(input("Enter the area: "))
rad2 = area / math.pi
rad2 = math.sqrt(rad2)
print("The radius is {:0.3}".format(rad2))
