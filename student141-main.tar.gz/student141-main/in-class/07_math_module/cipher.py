"""
In-Class Exercise:  Use code point to transform characters

File Name: cipyer.py
Course:    CPTR 141
"""

# Collect a lower case letter as input
lowercase = input("Enter a lower case letter: ")


# Print the code point representation of letter
print("The Unicode Character is", ord(lowercase))

# Print the capitalize the letter (32 code points below)
print("The capitial letter is", chr(ord(lowercase) - 32))

# Collect the Caesar Cipher alphabet shift
offset =  int(input("\nEnter Cipher offset: "))

# Print the lower case letter's cipher character
print("The cipher Character is: ",chr(ord(lowercase) + offset))