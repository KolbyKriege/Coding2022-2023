"""
Demonstration/Exercise: A factorial function

File Name: factorial.py
Course:    CPTR 141
"""

import factorial_function

n = int(input("Enter a number n: "))

val = factorial_function.factorial(n)
print("{}! = {}".format(n, val))
