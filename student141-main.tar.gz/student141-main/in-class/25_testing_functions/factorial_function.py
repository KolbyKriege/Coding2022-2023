def factorial(n):
    """
    n is a non negative interager
    Reurtns the factorirl of n. This is the product of all intergers from 1 up to  n and include n.
    """
    result = 1
    for i in range(1,n + 1):
        result *= i
    return result