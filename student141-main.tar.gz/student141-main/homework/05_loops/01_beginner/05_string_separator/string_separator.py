"""
Beginner Problem:  Output each character of a user-entered string
                   separated by "-" characters

File Name: string_separator.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
String = input("Enter a string: ")
print()
print("Did you enter",end=" ")
for i in range(0,(len(String))):
    if i ==(len(String)-1):
        print(String[i], end="?")
        break
    print(String[i], end="-")
print()