"""
Beginner Problem: List all lower case characters in the alphabet that come
                  before a given character in reverse order

File Name: reverse_alphabet.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
