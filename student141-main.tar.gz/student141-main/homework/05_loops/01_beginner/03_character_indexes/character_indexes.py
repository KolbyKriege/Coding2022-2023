"""
Beginner Problem: Write a program that finds the indexes of all
                  occurrences of a given character within a
                  given string. Treat upper and lower case the same

File Name: character_indexes.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
index = []
string = input("Enter a string: ")
charater = input("Enter the character to search for: ")
print()
for i in range(0,len(string)):
    if charater == string[i]:
        index.append(i)
if len(index)==0:
    print('The character "{}" does not appear in the given string.'.format(charater))
else:
    print('The character "{}" appears at indexes {}.'.format(charater, index))