"""
DO NOT MODIFY

This file contains the pre-defined variables for this homework problem.  You should
not modify the contents of this file, but rather do your work in the file menu_items.py.
"""

dishes = {
    "Pumpkin pie": 6.99,
    "10-pc Nuggets": 3.99,
    "Burger Sliders": 8.99,
    "Chicken soup": 12.99,
    "Breadsticks": 1.99,
    "Mac & Cheese": 14.99,
    "Banana Pancakes": 6.99,
}
