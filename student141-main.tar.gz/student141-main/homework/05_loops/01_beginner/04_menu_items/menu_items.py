"""
Beginner Problem:  Outputs all menu dishes that cost no more than a given price.

File Name: menu_items.py
Name:      ?
Course:    CPTR 141
"""

import menu

# Your code goes here
print("=========================== CPTR 141 Restaurant ===========================")
print("Welcome! Tell me how much you want to spend and I'll tell you what we have.")
buget = float(input("What is your budget? $"))
print()
print("You can get:")
for i in range(0,len(menu.dishes)):
    if buget >= menu.dishes.get("Pumpkin pie"):
        print("  * Pumpkin pie for ${}".format(menu.dishes.get("Pumpkin pie")))
    
    if buget >= menu.dishes.get("10-pc Nuggets"):
        print("  * 10-pc Nuggets for ${}".format(menu.dishes.get("10-pc Nuggets")))
    if buget >= menu.dishes.get("Burger Sliders"):
        print("  * Burger Sliders for ${}".format(menu.dishes.get("Burger Sliders")))
    if buget >= menu.dishes.get("Chicken soup"):
        print("  * Chicken soup for ${}".format(menu.dishes.get("Chicken soup")))
    if buget >= menu.dishes.get("Breadsticks"):
        print("  * Breadsticks for ${}".format(menu.dishes.get("Breadsticks")))
    if buget >= menu.dishes.get("Mac & Cheese"):
        print("  * Mac & Cheese for ${}".format(menu.dishes.get("Mac & Cheese")))
    if buget >= menu.dishes.get("Banana Pancakes"):
        print("  * Banana Pancakes for ${}".format(menu.dishes.get("Banana Pancakes")))