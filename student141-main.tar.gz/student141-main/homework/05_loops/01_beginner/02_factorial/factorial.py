"""
Beginner Problem: Write a program that outputs the factorial of a given
                  non-negative integer.

File Name: factorial.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here

number = int(input("Enter the value for which you wish to find the factorial: "))
end_number = number
if (end_number == 0):
    print("\n0! = 1")
elif (end_number <= -1):
    print("\nError! Factorial does not exist for negative numbers.")
else:
    for i in range(1,number):
        number = i* number
    print("\n{}! = {}".format(end_number , number))