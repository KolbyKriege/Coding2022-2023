"""
Beginner Problem: Create a program that prompts the user to enter numbers,
                  continuing until the user enters a zero.  The program then
                  prints the sum of all numbers entered.

File Name: sum_of_numbers.py
Name:      ?
Course:    CPTR 141
"""
number = 1
final = 0
while number != 0:
    number = float(input("Enter a number ('0' to quit): "))
    final = number + final
print()
if final == 0:
    print("Total Sum: {:0.4}0".format(final))
else:
    print("Total Sum: {:0.4}".format(final))