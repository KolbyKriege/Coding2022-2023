"""
Intermediate Problem:  Check to see if entered numbers are prime

File Name: prime_checker.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes her
repeat = True
prime = False
print("===== Prime Checker =====")
while repeat == True:

    number = int(input("Enter a number: "))
    for i in range(2, int(number/2)+1):
        if ((number % i) == 0):
            print(number, "is not a prime number")
            break
    else:
        if number == 1:
            print(number, "is not a prime number")
        else:
            print(number, "is a prime number")
    while repeat == True:
        user_repeat = input("Would you like to enter another (y/n)? ")
        if user_repeat == 'n':
            repeat = False
            print("\nGoodbye!")
        if user_repeat == 'y':
            print()
            repeat = True
            break
