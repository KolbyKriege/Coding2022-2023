"""
Intermediate Problem: Generate Multiplication Tables
File Name: multiplication_table.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
