"""
Intermediate Problem:  Create a program that prompts the user an indeterminte number of
                       first/last name pairs and creates a dictionary with the CS lab
                       username as keys and full names as values.

File Name: username_dictionary.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
cs_lab_users = {}
repeat = True
print("Welcome to CS Lab User Database")
print("===============================")
while repeat == True:
    frist_name1 = input("Enter first name of user #1: ")
    last_name1= input("Enter last name of user #1: ")
    username1 = last_name1[0] + last_name1[1] +last_name1[2] +last_name1[3] +frist_name1[0]+frist_name1[1]
    print("Generated Username: {}".format(username1))
    respone = input("Enter another user (y/n)? ")
    if respone == 'y':
        repeat = False