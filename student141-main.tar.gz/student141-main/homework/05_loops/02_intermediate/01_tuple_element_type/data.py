"""
DO NOT MODIFY

This file contains the pre-defined variables for this homework problem.  You should
not modify the contents of this file, but rather do your work in the file
tuple_element_type.py.
"""

my_tuple = (
    True,
    "923.18",
    "Cat",
    "ocean",
    "z",
    "q",
    54.23,
    94,
    "54.23",
    100.99,
    52,
    False,
    True,
    False,
    "True",
    "planet",
)
