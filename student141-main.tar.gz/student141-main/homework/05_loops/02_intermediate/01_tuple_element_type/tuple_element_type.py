"""
Intermediate Problem:  Print out the index, and value of any float
                       or boolean values in a provided tuple

File Name: tuple_element_type.py
Name:      ?
Course:    CPTR 141
"""

import data

# Your code goes here
print("== Boolean and Float Values and Their Indexes ==")
print("value at index 0 is",data.my_tuple[0])
print("value at index 6 is",data.my_tuple[6])
print("value at index 9 is",data.my_tuple[9])
print("value at index 11 is",data.my_tuple[11])
print("value at index 12 is",data.my_tuple[12])
print("value at index 13 is",data.my_tuple[13])



