"""
Intermediate Problem:  Create a program that builds a truncated triangle based
                       on user-input criteria

File Name: nested_pattern.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
