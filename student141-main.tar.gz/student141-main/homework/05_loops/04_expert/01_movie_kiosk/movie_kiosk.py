"""
Expert Problem:  Create a program that mimics a movie theater kiosk and allows
                 users to purchase tickets or snacks, presenting a final receipt
                 when they are done.

File Name: movie_kiosk.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
import data
num_moives = {
    1: 'Back to the Future',
    2: 'Braveheart',
    3: 'Blood Diamond',
    4: 'Avatar',
    5: 'Alice in Wonderland',
    6: 'Lord of the Rings',
    7: 'The Matrix',
    8: 'The Croods'
}

num_snacks = {
    1: 'Twizzlers',
    2: 'Soft Pretzels',
    3: 'Small Popcorn',
    4: 'Medium Popcorn',
    5: 'Large Popcorn',
    6: 'Chex Snack Mix',
    7: 'Pretzel Challah Bagel Dogs'
}
numbers = (1, 2, 3, 4, 5, 6, 7, 8)
infi = 1
snack_choise = 0
moive_choise = 0
moive_purchase = 0
snack_purchase = 0
repeat = False
print("******** MOVIE KIOSK v0.1 *******")
while infi == 1:
    respone = 0
    print("\nOptions:")
    print(" 1) Purchase Movie Ticket from List")
    print(" 2) Purchase Snacks from List")
    print(" 3) Check Out and View Receipt\n")

    respone = int(input("Enter desired option number: "))
    while repeat == False:
        if (respone > 4):
            print()
            print("Error! Invalid Entry. Please Select One of:")
            break
        else:
            repeat = True
    repeat = False
    while repeat == False:
        if respone == 1:
            print("\n=== Select Movie ===")
            print("1. Back to the Future (${})".format(
                data.movies['Back to the Future']))
            print("2. Braveheart (${})".format(data.movies['Braveheart']))
            print("3. Blood Diamond (${})".format(
                data.movies['Blood Diamond']))
            print("4. Avatar (${})".format(data.movies['Avatar']))
            print("5. Alice in Wonderland (${})".format(
                data.movies['Alice in Wonderland']))
            print("6. Lord of the Rings (${})".format(
                data.movies['Lord of the Rings']))
            print("7. The Matrix (${})".format(data.movies['The Matrix']))
            print("8. The Croods (${})".format(data.movies['The Croods']))
            moive_choise = int(input("Enter Choice: "))
            moive_purchase += 1
        while repeat == False:
            if (0 > moive_choise) or (moive_choise >= 8):
                moive_choise = int(input("Error! Enter Valid Choice: "))
                repeat = False
            else:
                repeat = True
    repeat = False
    while repeat == False:
        if respone == 2:
            print("\n=== Select Snack ===")
            print("1. Twizzlers (${})".format(data.snacks['Twizzlers']))
            print("2. Soft Pretzels (${})".format(
                data.snacks['Soft Pretzels']))
            print("3. Small Popcorn (${})".format(
                data.snacks['Small Popcorn']))
            print("4. Medium Popcorn (${})".format(
                data.snacks['Medium Popcorn']))
            print("5. Large Popcorn (${})".format(
                data.snacks['Large Popcorn']))
            print("6. Chex Snack Mix (${})".format(
                data.snacks['Chex Snack Mix']))
            print("7. Pretzel Challah Bagel Dogs (${})".format(
                data.snacks['Pretzel Challah Bagel Dogs']))
            snack_choise = int(input("Enter Choice: "))
            snack_purchase += 1
        while repeat == False:
            if (0 > snack_choise) or (snack_choise >= 7):
                snack_choise = int(input("Error! Enter Valid Choice: "))
                repeat = False
            else:
                repeat = True
    if respone == 3:
        if moive_choise == 0:
            print()
            print("---------- Receipt ----------")
            print(
                "$ {} -- {}".format(data.snacks[num_snacks[snack_choise]]*snack_purchase, num_snacks[snack_choise]))
            print("-----------------------------")
            print(
                "$ {} -- Total Price".format(((data.snacks[num_snacks[snack_choise]]*snack_purchase))))
            print()
            print("Thank you for your purchase, we hope to see you again!")
        elif snack_choise == 0:
            print()
            print("---------- Receipt ----------")
            print(
                "$ {} -- {}".format(data.movies[num_moives[moive_choise]]*moive_purchase, num_moives[moive_choise]))
            print("-----------------------------")
            print(
                "$ {} -- Total Price".format((data.movies[num_moives[moive_choise]]*moive_purchase)))
            print()
            print("Thank you for your purchase, we hope to see you again!")
        else:
            print()
            print("---------- Receipt ----------")
            print(
                "$ {} -- {}".format(data.movies[num_moives[moive_choise]]*moive_purchase, num_moives[moive_choise]))
            print(
                "$ {:>5} -- {}".format(data.snacks[num_snacks[snack_choise]]*snack_purchase, num_snacks[snack_choise]))
            print("-----------------------------")
            print("$ {} -- Total Price".format((data.movies[num_moives[moive_choise]]*moive_purchase)+(
                data.snacks[num_snacks[snack_choise]]*snack_purchase)))
            print()
            print("Thank you for your purchase, we hope to see you again!")
            break
        break