"""
DO NOT MODIFY

This file contains the pre-defined variables for this homework problem.  You should
not modify the contents of this file, but rather do your work in the file
movie_kiosk.py.
"""

movies = {
    "Back to the Future": 12.99,
    "Braveheart": 13.99,
    "Blood Diamond": 11.99,
    "Avatar": 14.99,
    "Alice in Wonderland": 13.99,
    "Lord of the Rings": 12.99,
    "The Matrix": 12.99,
    "The Croods": 11.99,
}

snacks = {
    "Twizzlers": 3.99,
    "Soft Pretzels": 6.99,
    "Small Popcorn": 4.99,
    "Medium Popcorn": 10.99,
    "Large Popcorn": 15.99,
    "Chex Snack Mix": 1.99,
    "Pretzel Challah Bagel Dogs": 9.99,
}
