"""
Expert Problem:  Create a program that generates a checker board
                 of the given dimensions

File Name: checker_board.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
print("******* CHECKER BOARD GENERATOR ******")
print("* Dimensions May Not Exceed 50 x 50  *")
print("**************************************")
num_rows = int(input("Enter the number of rows (1-10): "))
num_cols = int(input("Enter the number of columns (1-10): "))
num_squ_size = int(input("Enter the square size (1-10): "))
charater = input("Enter the shading character: ")
for k in range(num_rows):
    for i in range(num_cols):
        for j in range(num_squ_size):
            j += 1
            print(charater, end='')
        print()
    print()
