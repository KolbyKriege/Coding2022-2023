"""
Intermediate Problem: Create a functions that groups numbers from the command line
                      and classifies them based on their leading digits.

File Name: group_numbers.py
Name:      ?
Course:    CPTR 141
"""


# Write Your Function Here
