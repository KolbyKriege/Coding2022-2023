"""
Intermediate Problem: Create functions to count items in lists nested in dictionaries
                      and to add an item to the shortest list in the  dictionary.

File Name: list_in_dict.py
Name:      ?
Course:    CPTR 141
"""

# Write Your Code here
