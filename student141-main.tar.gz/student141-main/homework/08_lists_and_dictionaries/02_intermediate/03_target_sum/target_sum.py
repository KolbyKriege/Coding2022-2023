"""
Intermediate Problem: Create a functions returns a list of tuples
                      that add to the target sum.

File Name: target_sum.py
Name:      ?
Course:    CPTR 141
"""


# Your code goes here
