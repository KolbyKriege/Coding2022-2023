"""
Intermediate Problem: Create a functions that locates the first instance of
                      the maximum in a 2D nested list of integers.

File Name: global_max.py
Name:      ?
Course:    CPTR 141
"""


# Write Your Function Here
def max_indices (lists):
    maxium = 0 
    for row in range(len(lists)):
        for numbs in lists[row]:
            if numbs > maxium:
                maxium = max(lists[row])
                lists_row = row
                lists_col = lists[row].index(maxium)
    return lists_row, lists_col
