"""
Expert Problem:  Functions for a tic-tac-toe game

File Name: ttt_functions.py
Name:      ?
Course:    CPTR 141
"""


def print_board(board):
    print(" {} | {} | {} ".format(board[0][0], board[0][1], board[0][2]))
    print("---+---+---")
    print(" {} | {} | {} ".format(board[1][0], board[1][1], board[1][2]))
    print("---+---+---")
    print(" {} | {} | {} ".format(board[2][0], board[2][1], board[2][2]))
    pass


def play(symbol, row, col, board):
    if board[row][col] == ' ':
        board[row][col]= symbol
        temp = True
    else:
        temp = False

    return temp


def can_play(board):
    for i in range(3):
        if (board[i].count(' ') != 0):
            temp = True
        else:
            temp =  False
    return temp


def check_win(board):
    n = len(board)
    for i in range(n):
        temp = True
        for j in range(n):
            if board[i][j] != 'O':
                temp= False
                break
        if temp == True:
            return board[i][j]
    temp = True

    for i in range(n):
        if board[i][i] != 'X':
            temp = False
            break

    if temp == True:
        return board[i][i]

    temp = True
    for i in range(n):
        if board[i][n - 1 - i] != 'X':
            temp = False
            break
    if temp == True:
        return board[i][n - 1 - i]
    return False
