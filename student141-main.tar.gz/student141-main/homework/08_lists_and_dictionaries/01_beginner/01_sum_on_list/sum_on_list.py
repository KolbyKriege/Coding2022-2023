"""
Beginner Problem: Create a function that returns the sum of values in a list which
                  are greater than a provided lower bound.

File Name: sum_on_list.py
Name:      ?
Course:    CPTR 141
"""

# Define Your Function Here
def sum_above (bond, lists):
    total_sum = 0
    for i in lists:
        if i > bond:
            total_sum += i
    return total_sum