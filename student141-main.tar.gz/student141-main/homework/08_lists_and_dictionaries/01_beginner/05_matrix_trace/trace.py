"""
Beginner Problem:  Create a function that returns the trace of a square matrix.

File Name: trace.py
Name:      ?
Course:    CPTR 141
"""


# Write Your Function Here
