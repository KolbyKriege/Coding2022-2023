"""
Beginner Problem: Create functions that sort strings ignoring letter case.

File Name: caseless_sort.py
Name:      ?
Course:    CPTR 141
"""

# Write your function here
