"""
Beginner Problem: Create a function that squares each number in a list.

File Name: square_list.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
