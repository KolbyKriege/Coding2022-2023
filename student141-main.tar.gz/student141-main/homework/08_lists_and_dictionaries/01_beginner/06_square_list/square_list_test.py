"""
Implement your function in the file square_list.py

Use this file to test your function.  The code you write in this file will
not be graded.
"""

import square_list

my_list = [1, 2, 3, 4, 5, 6]
new_list = square_list.square_list(my_list)

print("The lists are:\n - original: {}\n - new: {}".format(my_list, new_list))
