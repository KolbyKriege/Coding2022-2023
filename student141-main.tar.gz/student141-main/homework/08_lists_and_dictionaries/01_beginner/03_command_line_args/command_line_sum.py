"""
Beginner Problem: Write a program that prints the sum of two command-line arguments.

File Name: command_line_sum.py
Name:      ?
Course:    CPTR 141
"""


# Write your function here
