"""
Beginner Problem:  Write a function computes the average age of students in a
                   nested dictionary structure.

File Name: nested_dict_avg.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
