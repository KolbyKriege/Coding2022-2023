"""
Beginner Problem:  Create a program that saves three companies the user
                   wishes to work at in a tuple list. Output tuple list.

File Name: company_list.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
