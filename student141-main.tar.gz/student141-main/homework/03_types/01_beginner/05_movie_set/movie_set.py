"""
Beginner Problem:  Create a program that outputs the intersection and
                   union of the two movie sets.

File Name: movie_set.py
Name:      ?
Course:    CPTR 141
"""

import movies

# Your code goes here
