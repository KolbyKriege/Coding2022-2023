"""
DO NOT MODIFY

This file contains the pre-defined variables for this homework problem.  You should
not modify the contents of this file, but rather do your work in the file movie_set.py.
"""

first_movie_set = {
    "The Godfather",
    "Bonnie and Clyde",
    "Wall-E",
    "Ghostbusters",
    "Braveheart",
    "The Lord of the Rings: The Return of the King",
    "Beauty and the Beast",
    "Up",
    "Rocky",
}

second_movie_set = {
    "Vertigo",
    "Gladiator",
    "Monty Python and The Holy Grail",
    "Avatar",
    "Ghostbusters",
    "Up",
    "Rocky",
    "The Lion King",
    "Mary Poppins",
    "The Dark Knight",
}
