"""
Beginner Problem:  Removes duplicate names of insurance copmanies from a provided list.

File Name: insurance_list_to_set.py
Name:      ?
Course:    CPTR 141
"""

import names

# Your code goes here
