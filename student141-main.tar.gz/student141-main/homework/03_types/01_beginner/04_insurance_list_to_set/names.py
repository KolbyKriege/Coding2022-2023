"""
DO NOT MODIFY

This file contains the pre-defined variables for this homework problem.  You should
not modify the contents of this file, but rather do your work in the file insurance_list_to_set.py.
"""

insurance_names = [
    "Allstate",
    "GEICO",
    "Ironshore",
    "Chubb Corp",
    "Aflac",
    "Allstate",
    "Safeco",
    "USAA",
    "Allstate",
    "Chubb Corp",
    "The Regence Group",
    "The General",
    "Aflac",
    "West Coast Life",
]
