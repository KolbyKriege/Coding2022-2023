"""
Beginner Problem:   Write a program that outputs a list of three planet
names the user wishes to never visit, then output the middle planet name in the list.

File Name: planets_list.py
Name:      ?
Course:    CPTR 141
"""

planet_names = []

# Your code goes here
