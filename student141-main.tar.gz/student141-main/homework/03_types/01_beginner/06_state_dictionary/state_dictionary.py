"""
Beginner Problem: Create a program that adds two new keys to an existing dictionary
                  containing states abbreviations and their capitols.

File Name: state_dictionary.py
Name:      ?
Course:    CPTR 141
"""

state_capitols = {
    "CA": "Sacramento",
    "OR": "Salem",
    "WA": "Olympia",
    "TX": "Austin",
    "NY": "Albany",
}

# Your code goes here
