"""
Beginner Problem:  Create a program that outputs the first character and
                   length of a country the user wishes to visit.

File Name: country_string.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
