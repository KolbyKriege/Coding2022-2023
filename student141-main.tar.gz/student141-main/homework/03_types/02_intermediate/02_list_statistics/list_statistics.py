"""
Intermediate Problem:  Create a program that builds a list of numbers and computes the
                       smallest, largest, and sum of the values from the list.

File Name: list_statistics.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
