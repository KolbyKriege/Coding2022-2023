"""
Intermediate Problem:  Create a program that collects answers to a 10-point multiple
                       choice quiz and then reports the distributions of answers

File Name: quiz_stats.py
Name:      ?
Course:    CPTR 141
"""

choices = {'a': 0, 'b': 0, 'c': 0, 'd': 0}

# Your code goes here
print("Quiz Statistics: Enter your answers to the questions below")
print("----------------------------------------------------------")
question1 = input("Question 1: ")
question2 = input("Question 2: ")
question3 = input("Question 3: ")
question4 = input("Question 4: ")
question5 = input("Question 5: ")
question6 = input("Question 6: ")
question7 = input("Question 7: ")
question8 = input("Question 8: ")
question9 = input("Question 9: ")
question10 = input("Question 10: ")

choices[question1.lower()] = (choices[question1.lower()] +1 )
choices[question2.lower()] = (choices[question2.lower()] +1 )
choices[question3.lower()] = (choices[question3.lower()] +1 )
choices[question4.lower()] = (choices[question4.lower()] +1 )
choices[question5.lower()] = (choices[question5.lower()] +1 )
choices[question6.lower()] = (choices[question6.lower()] +1 )
choices[question7.lower()] = (choices[question7.lower()] +1 )
choices[question8.lower()] = (choices[question8.lower()] +1 )
choices[question9.lower()] = (choices[question9.lower()] +1 )
choices[question10.lower()] = (choices[question10.lower()] +1 )

number_a = choices['a']/10
number_b = choices['b']/10
number_c = choices['c']/10
number_d = choices['d']/10
print()
print("You answered:")
print("  - 'a'",int(number_a *100), "percent of the time")
print("  - 'b'",int(number_b *100), "percent of the time")
print("  - 'c'",int(number_c *100), "percent of the time")
print("  - 'd'",int(number_d *100), "percent of the time")