"""
Intermediate Problem:  Create a program that prompts the user three first/last name
                       pairs and creates a dictionary with the CS lab username as
                       keys and full names as values.

File Name: username_dictionary.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
