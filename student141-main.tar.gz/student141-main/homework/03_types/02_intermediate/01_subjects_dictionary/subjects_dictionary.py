"""
Intermediate Problem:  Create a program that collects the name of three academic
                       subjects and then creates a dictionary with the subject name
                       as the key and its length as the value. Finally, output the
                       dictionary and the average length of the three subjects.

File Name: subjects_dictionary.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
