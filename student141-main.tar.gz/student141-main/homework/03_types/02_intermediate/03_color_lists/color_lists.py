"""
Intermediate Problem:  Create a program asking the user to pick a name from a given
                       list which then looks up the favorite color in a parallel list.

File Name: color_lists.py
Name:      ?
Course:    CPTR 141
"""

import lists

# Your code goes here
