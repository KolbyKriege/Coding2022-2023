"""
DO NOT MODIFY

This file contains the pre-defined variables for this homework problem.  You should
not modify the contents of this file, but rather do your work in the file color_lists.py.
"""

person_name = ["Violette", "Diego", "Sam", "Mary", "Emma", "George"]
favorite_color = ["Red", "Blue", "Blue", "Purple", "Green", "Red"]
