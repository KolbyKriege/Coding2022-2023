"""
Expert Problem: Create a program that prompts the user for two (x,y) points,
                stores them as tuples, and then computes the equation of a
                line through those points.

File Name: line_equation_tuples.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
print("Enter First Point")
print("=================")
x1 = float(input("x-coordinate: "))
y1 = float(input("y-coordinate: "))
point_one = (x1, y1)
print("Point #1 is", point_one)
print()

print("Enter Second Point")
print("==================")
x2 = float(input("x-coordinate: "))
y2 = float(input("y-coordinate: "))
point_two = (x2, y2)
print("Point #2 is", point_two)
print()

slope = (point_two[1]-point_one[1])/(point_two[0]-point_one[0])

y_intercept = point_one[1] - (slope*point_one[0])


print("Equation")
print("========")
print("The equation of the line through the points",
      point_one, "and", point_two, "is:")
print("y = {:0.2f}".format(slope)+ "x + ({:0.2f}".format(y_intercept)+")")
