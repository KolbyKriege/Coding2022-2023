"""
Expert Problem: Create a program that prompts the user information about
                their pets, including birth year, and then prints out the
                pets' ages in a future year.

File Name: pet_age_calculate.py
Name:      ?
Course:    CPTR 141
"""
print("First Pet's Info:")
print("=================")
name1 = input("Name: ")
type1 = input("Type: ")
born1 = int(input("Birth Year: "))
print("")

print("Second Pet's Info:")
print("=================")
name2 = input("Name: ")
type2 = input("Type: ")
born2 = int(input("Birth Year: "))
print("")

print("Third Pet's Info:")
print("================")
name3 = input("Name: ")
type3 = input("Type: ")
born3 = int(input("Birth Year: "))
print("")

year = int(input("Enter a Year: "))
# use these lists or your program will not pass the autograder
pet_name = [name1, name2, name3]
pet_type = [type1, type2, type3]
pet_born = [born1, born2, born3]

# your code goes here
print()
print("In", str(year)+", the ages of your pets will be:" )
print("  -",pet_name[0],"the",str(pet_type[0].lower()),"will be",year-pet_born[0])
print("  -",pet_name[1],"the",str(pet_type[1].lower()),"will be",year-pet_born[1])
print("  -",pet_name[2],"the",str(pet_type[2].lower()),"will be",year-pet_born[2])
