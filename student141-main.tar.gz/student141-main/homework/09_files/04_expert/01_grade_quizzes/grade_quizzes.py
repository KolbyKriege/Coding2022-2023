"""
Expert Problem: Quiz Grader

File Name: grade_quizzes.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
import os
import os.path
def grade_quizzes (student_quizzes, answers, grades):
    with open(grades,'w') as temp1:
        temp1.write("Student File,Correct,Total,Pass or Fail\r\n")
    with open(answers) as answer_file:
        test = answer_file.read()
        test = test.strip()
        test = test.split()
        answer_list = test
        temp = (os.listdir(student_quizzes))
        temp = sorted(temp)
        
        for x in temp:
            with open(student_quizzes+"/{}".format(x),'r') as student_quiz:
                correct = 0
                question = 0
                test1 = student_quiz.read()
                test1 = test1.strip()
                test1 = test1.split()
                student_quiz = test1
                for j in range(len(answer_list)):
                    if answer_list[j] == student_quiz[j]:
                        correct += 1
                        question += 1
                    else:
                        question += 1
                if (correct/question) >= 0.7:
                    PandF = "Pass"
                else:
                    PandF = "Fail"
            with open(grades, 'a') as final: 
                final.write("{},{},{},{}\r\n".format(x,correct,question,PandF))
