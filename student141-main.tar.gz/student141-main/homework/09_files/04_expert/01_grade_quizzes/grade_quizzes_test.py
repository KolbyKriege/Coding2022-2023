"""
Implement your function in the file grade_quizzes.py

Use this file to test your function.  The code you write in this file will
not be graded.
"""


import grade_quizzes

grade_quizzes.grade_quizzes("student_quizzes", "answers.txt", "grades.csv")
