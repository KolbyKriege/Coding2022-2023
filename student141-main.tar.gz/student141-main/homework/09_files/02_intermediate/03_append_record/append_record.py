"""
Intermediate Problem: Create a function that appends a record to a file.
                      The record must match the table spacing in the file.

File Name: append_record.py
Name:      ?
Course:    CPTR 141
"""


# Your code goes here
