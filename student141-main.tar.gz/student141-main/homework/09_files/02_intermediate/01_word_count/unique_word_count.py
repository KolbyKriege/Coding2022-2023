"""
Intermediate Problem: Create a functions reads a file's contents
    and creates a dictionary where each key is a unique word
    and the value is the number of occurrences.

File Name: unique_word_count.py
Name:      ?
Course:    CPTR 141
"""


# Your code goes here
def unique_word_count (file):
    word_count = {}
    with open(file) as lyrics:
        lyrics = lyrics.read()
        lyrics = lyrics.lower()
        lyrics = lyrics.strip()
        lyrics = lyrics.split()
        #print(lyrics)
        for x in lyrics:
            if ',' in x:

                index = x.index(',')
                lyrics = x.replace(x, x[0:index])

        for x in lyrics:
            count = lyrics.count(x)
                                                            #print(count)
                                                            #if x not in word_count:
            word_count[x]= count
    return word_count