"""
Intermediate Problem: Create a functions that merges two files into one file.
                      Only keep the first unique id number in the final file.

File Name: merging_csv_files.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
