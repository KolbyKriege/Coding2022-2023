"""
Intermediate Problem:  Create a function that reads a file with one arithmetic operations per line,
    then computes the answer and writes it another file.

File Name: calculator.py
Name:      ?
Course:    CPTR 141
"""


# your code goes here
def calculator (input_file, output_file):
    with open(input_file) as files:
        files = files.readlines()
        for x in files:
            x = x.rstrip()
            if "ADD" in x:
                temp = x.split()
                results = int(temp[1])+int(temp[2])
                with open(output_file,'a') as outputs:
                    outputs.write("{} + {} = {}\n".format(temp[1],temp[2],results))
            elif "SUBTRACT" in x:
                temp = x.split()
                results = int(temp[1])-int(temp[2])
                with open(output_file,'a') as outputs:
                    outputs.write("{} - {} = {}\n".format(temp[1],temp[2],results))
            elif x == "":
                with open(output_file,'a') as outputs:
                    outputs.write("\n")
            else: 
                temp = x.split()
                with open(output_file,'a') as outputs:
                    outputs.write("{} is an invalid operation.\n".format(temp[0]))