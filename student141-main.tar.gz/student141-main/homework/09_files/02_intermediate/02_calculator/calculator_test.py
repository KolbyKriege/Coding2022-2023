"""
Implement your function in the file calculator.py

Use this file to test your function.  The code you write in this file will
not be graded.
"""


import calculator

# test the commbine function
calculator.calculator("operations.txt", "results.txt")
