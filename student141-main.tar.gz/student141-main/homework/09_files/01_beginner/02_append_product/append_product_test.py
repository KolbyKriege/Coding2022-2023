"""
Implement your function in the file append_product.py

Use this file to test your function.  The code you write in this file will
not be graded.
"""

import append_product

# test the function
file_name = "products.txt"
product = "Pink Troll"
cost = 12.50
append_product.append_product(file_name, product, cost)
