"""
Beginner Problem: Create a function that appends a product and price to a text file.

File Name: append_product.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
