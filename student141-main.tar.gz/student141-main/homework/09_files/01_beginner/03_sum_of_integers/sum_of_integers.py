"""
Beginner Problem: Write a function that searches all words in a text file and returns the sum of all integer values.

File Name: sum_of_integers.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
