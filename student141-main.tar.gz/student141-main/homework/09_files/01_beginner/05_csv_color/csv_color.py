"""
Beginner Problem:  Create a function that writes the RGB color
    for a HEX color using a csv file to look up the conversion.

File Name: csv_color.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
