"""
Beginner Problem: Create a function that reads and prints out a text file.

File Name: read_file.py
Name:      ?
Course:    CPTR 141
"""

# Define Your Function Here
def read_file (text_file): 
    with open(text_file) as files:
        text = files.read()
        print(text)
    return(text)