"""
Implement your function in the file read_file.py

Use this file to test your function.  The code you write in this file will
not be graded.
"""

import read_file

file_name = "quote.txt"
print("The contents of {} is:\n{}".format(file_name, read_file.read_file(file_name)))
