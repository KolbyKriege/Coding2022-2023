"""
Implement your function in the file write_list.py

Use this file to test your function.  The code you write in this file will
not be graded.
"""

import write_list

# test the function
my_list = ["Apple", "Corn", "School", "Lava"]
write_list.write_list("example.txt", my_list)
