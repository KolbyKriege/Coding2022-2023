"""
Beginner Problem:  Return a list of files in a directory.

File Name: list_files.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
