"""
Beginner Problem:  Create a program that indicates if two words start with
                   the same letter.

File Name: matching_letter.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
