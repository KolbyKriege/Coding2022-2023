"""
Beginner Problem:  Create a program that outputs where a number lies
                   in relation to the interval [0,10].

File Name: number_in_range.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
num = float(input("Enter your number: "))
print()
if num < 0:
    print("The number", num ,"is below the interval [0,10].")
if num > 10:
    print("The number", num ,"is above the interval [0,10].")
if 0 <= num <= 10:
    print("The number", num ,"is in the interval [0,10].")