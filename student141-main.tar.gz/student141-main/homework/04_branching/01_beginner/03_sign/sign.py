"""
Beginner Problem: Create a program that outputs if a number is
                  positive, negative, or zero.

File Name: sign.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
num = float(input("Enter a number: "))
print()
if num < 0:
    print("The number", num ,"is negative.")
if num > 0:
    print("The number", num ,"is positive.")
if num == 0:
    print("The number", num ,"is neither positive nor negative.")