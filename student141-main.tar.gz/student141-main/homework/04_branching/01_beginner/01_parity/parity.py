"""
Beginner Problem:  Create a program that outputs if the number is even or odd.

File Name: parity.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
