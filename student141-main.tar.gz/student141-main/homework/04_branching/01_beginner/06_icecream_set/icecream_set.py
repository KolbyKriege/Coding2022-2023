"""
Beginner Problem: Create a program that determines if two given sets have
                  a non-empty intersection. Output the result.

File Name: icecream_set.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
