"""
DO NOT MODIFY

This file contains the pre-defined variables for this homework problem.  You should
not modify the contents of this file, but rather do your work in the file icecream_set.py.
"""

set_one = {
    "Banana",
    "Cherry",
    "Cookies and Cream",
    "Earl Grey",
    "Strawberry",
    "Rocky Road",
    "Mint",
    "Mango",
}

set_two = {
    "Strawberry Cheesecake",
    "Neapolitan",
    "Mamey",
    "Chocolate",
    "Vanilla",
    "Maple Walnut",
    "Mango",
    "Cookies and Cream",
}

set_three = {
    "Neopolitan",
    "Chocolate",
    "Salted Caramel",
    "Butterscotch",
    "Raspberry",
    "Lemon Cheesecake",
    "Vanilla",
}
