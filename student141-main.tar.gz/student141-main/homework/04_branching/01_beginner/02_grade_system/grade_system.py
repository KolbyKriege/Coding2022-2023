"""
Beginner Problem: Create a program that outputs the correct letter grade
                  when given a grade percentage.

File Name: grade_system.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
