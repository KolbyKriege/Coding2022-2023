"""
Expert Problem: Implement the classic game "Rock-Paper-Scissors"

File Name: rock_paper_scissors.py
Name:      ?
Course:    CPTR 141
"""

# your code goes here

import random
num_random = int(input("Enter a random seed: "))
random.seed(num_random)
comp_choise = random.randint(1,3)
print("The computer has chosen and so must you.")
print("  1) Rock")
print("  2) Paper")
print("  3) Scissors")
user_choise = int(input("Make your choice: "))
if (user_choise == 1) or (user_choise == 2) or (user_choise == 3):
    if comp_choise == 1:
        comp_choise_name = 'Rock'
    if comp_choise == 2:
     comp_choise_name = 'Paper'
    if comp_choise == 3:
        comp_choise_name = 'Scissors'

    if user_choise == comp_choise:
        result = "it's a tie!"
    if (user_choise == 1):
        if comp_choise == 3:
            result = "you win!"
        if comp_choise == 2:
            result = 'you lose!'

    if (user_choise == 2):
        if comp_choise == 1:
            result = "you win!"
        if comp_choise == 3:
            result = 'you lose!'

    if (user_choise == 3):
        if comp_choise == 2:
            result = "you win!"
        if comp_choise == 1:
            result = 'you lose!'

    print("The computer chose",comp_choise_name,"--",result) 
else:
    (print("Invalid choice. Please enter a number between 1 and 3.")) 