"""
Intermediate Problem: Create a program that solves the quadratic equation

File Name: quadratic_equation.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
import math

print("Enter the coefficients below: ")
num_a = int(input("  a = "))
num_b = int(input("  b = "))
num_c = int(input("  c = "))
if num_a == 0:
    print("Error! Not a quadratic equation.")

discriminant = math.pow(num_b, 2)-(4*num_c*num_a)

if discriminant > 0:
    soluaiton = 'two real roots']
    result1 = ((-num_b)+math.sqrt(discriminant))/(2*num_a)
    result12 = ((-num_b)-math.sqrt(discriminant))/(2*num_a)
if discriminant < 0:
    soluaiton = 'two complex roots'
    result1 = ((-num_b)+math.sqrt(discriminant))/(2*num_a)
    result12 = ((-num_b)-math.sqrt(discriminant))/(2*num_a) 
else:
    soluaiton = 'single real root'
