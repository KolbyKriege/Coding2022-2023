"""
Beginner Problem: Create a program that determines if one number
                  divides evenly into another.

File Name: evenly_divisible.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
num_1 = int(input("Enter the first number: "))
num_2 = int(input("Enter the second number: "))
print()
if (num_2 <= 0) or (num_1 <=0 ):
    print("Error! Numbers must be positive.")
if ((num_1 % num_2) == 0):
    print("The number", num_2 ,"divides evenly into {}.".format(num_1))
elif ((num_2 % num_1) == 0):
    print("The number", num_1 ,"divides evenly into {}.".format(num_2))
if ((num_1 % num_2) != 0):
    print("The number", num_1 ,"does not divides evenly into {}.".format(num_2))
elif ((num_2 % num_1) != 0):
    print("The number", num_2 ,"does not divides evenly into {}.".format(num_1))

