"""
Intermediate Problem: Create a program that mimics the basic arithmic functions
                      of a calculator.

File Name: basic_calculator.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
num_1 = int(input("Enter the first number: "))
operation = input("Enter the operator (+, -, *, or /): ")
num_2 = int(input("Enter the second number: "))
print()
if num_2 != 0:
    if (operation == '+') or  (operation == '-') or (operation == '*') or (operation == '/'):
        if operation == '+':
            result = num_1 + num_2
        if operation == '-':
            result = num_1 - num_2
        if operation == '*':
            result = num_1 * num_2
        if operation == '/':
            result = num_1 / num_2
    
    else:
        print("Invalid operation -- I don't know how to", operation+'.')
    print(num_1, operation, num_2, '=', result)
else:
    print("Error! Can not divide by zero.")