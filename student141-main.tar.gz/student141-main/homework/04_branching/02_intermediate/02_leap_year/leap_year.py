"""
Intermediate Problem:  Create a program that indicates if a given year is a leap
                       year or not.

File Name: leap_year.py
Name:      ?
Course:    CPTR 141
"""

# your code goes here
year = int(input("Enter year: "))
leap_year = False
year4= False
year10 = True
if (year % 4) == 0:
    year4 =  True
    if (year % 100) == 0:
        if ((year % 400) == 0):
            leap_year = True            
    else:
        year10 = False
        
if (leap_year ==True) or ((year4 == True) and (year10 == False)):
    print("The year",year,"is a leap year.")
else:
    print("The year",year,"is not a leap year.")