"""
Intermediate Problem: Create a program that outputs the total price of an item
                      after any discounts have been applied.

File Name: total_price.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
