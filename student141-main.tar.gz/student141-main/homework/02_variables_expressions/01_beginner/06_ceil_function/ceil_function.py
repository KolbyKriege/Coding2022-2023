"""
Beginner Problem: Create a program that outputs a value using the ceil function from the math module

File Name: ceil_function.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
