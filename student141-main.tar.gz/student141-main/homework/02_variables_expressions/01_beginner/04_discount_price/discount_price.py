"""
Beginner Problem:  Create a program that outputs the discounted price of an item

File Name: discount_price.py
Name:      ?
Course:    CPTR 141
"""
DISCOUNT_RATE = 0.45

# Your code goes here
