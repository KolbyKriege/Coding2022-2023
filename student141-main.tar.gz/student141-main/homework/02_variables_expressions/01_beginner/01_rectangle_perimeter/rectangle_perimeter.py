"""
Beginner Problem:  Create a program that outputs the perimeter of a rectangle

File Name: rectangle_perimeter.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
lenght = int (input("Enter the length: "))
whidth = int (input ("Enter the width: "))
perimeter = (2*lenght) + ( 2* whidth)
print()
print ("The perimeter of the rectangle is", perimeter)