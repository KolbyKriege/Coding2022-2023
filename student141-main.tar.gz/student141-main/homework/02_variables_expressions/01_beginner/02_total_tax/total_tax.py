"""
Beginner Problem:  Create a program that outputs the taxation of an item price to two decimal places

File Name: total_tax.py
Name:      ?
Course:    CPTR 141
"""
TAX_RATE = 0.065

# Your code goes here
price = float(input("Enter the price of the item: $"))
print()
tax = price * TAX_RATE
print("Tax:   $""{:0.2f}".format(tax))