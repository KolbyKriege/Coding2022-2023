"""
Beginner Problem:  Create a program that outputs the distribution of cookies each person can receive and any leftovers

File Name: cookie_distribution.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
cookies = int(input("Enter number of cookies: "))
people = int(input("Enter number of people: "))
print()
num_per_poeple = cookies // people
left_overs = cookies % people
print("Each person gets", num_per_poeple,"cookies and there will be",left_overs,"left over.")
