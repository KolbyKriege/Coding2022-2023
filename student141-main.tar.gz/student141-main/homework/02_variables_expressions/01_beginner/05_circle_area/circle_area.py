"""
Beginner Problem:  Create a program that outputs the area of a circle

File Name: circle_area.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
