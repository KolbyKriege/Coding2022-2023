"""
Expert Problem:  TV Schedule

File Name: tv_schedule.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
filltime = float(input("Enter number of minutes to fill: "))
hour = filltime // 60
minutes = (filltime - (hour * 60))
print()
print(int(hour),"hour(s) and",int(minutes),"minute(s) can hold the following items: ")

drama = filltime // 52
filltime %= 52

sittcon = filltime // 24
filltime %= 24

New_Break = filltime // 2.5
filltime %= 2.5

Adver = filltime // .5
filltime %= .5

print("  - Dramas:",int(drama))
print("  - Sitcoms:",int(sittcon))
print("  - News Breaks:",int(New_Break))
print("  - Advertisements:",int(Adver))