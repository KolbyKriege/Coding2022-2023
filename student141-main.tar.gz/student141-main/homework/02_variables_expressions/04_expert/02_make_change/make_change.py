"""
Expert Problem: Make change using various currency

File Name: make_change.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
# promte user to enter cost and paid
cost = float(input("Enter the cost in dollars and cents: $"))
paid = float(input("Enter the amount paid in dollars and cents: $"))
print()
payback = paid - cost

num_20 = payback // 20
payback = payback % 20

num_10 = payback // 10
payback = payback % 10

num_5 = payback // 5
payback = payback % 5

num_1 = payback // 1
payback = payback % 1

num_025 = payback // 0.25
payback = payback % .25

num_010 = payback // 0.1
payback = payback % .1

num_005 = payback // 0.05
payback = payback % .05

num_001 = payback // 0.01
payback -= payback

print("Your change is:")
print("  - twenty-dollar bills:", int(num_20))
print("  - ten-dollar bills:", int(num_10))
print("  - five-dollar bills:", int(num_5))
print("  - one-dollar bills:", int(num_1))
print("  - quarters:", int(num_025))
print("  - dimes:", int(num_010))
print("  - nickels:", int(num_005))
print("  - pennies:", int(num_001))