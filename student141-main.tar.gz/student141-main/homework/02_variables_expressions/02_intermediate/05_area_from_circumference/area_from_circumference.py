"""
Intermediate Problem: Create a program computes the area of a circle
                      with a given circumference

File Name: area_from_circumference.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
