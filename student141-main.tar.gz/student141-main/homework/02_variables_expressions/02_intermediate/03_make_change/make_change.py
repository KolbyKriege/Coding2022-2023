"""
Intermediate Problem:  Create a program that outputs the user bill in change

File Name: make_change.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
