"""
Intermediate Problem: Create a program that outputs the hypotenuse

File Name: hypotenuse.py
Name:      ?
Course:    CPTR 141
"""
import math
# Your code goes here
aleg = float(input("Enter leg A length: "))
bleg = float(input("Enter leg B length: "))
print()
hypotenuse = math.sqrt(math.pow(aleg,2)+math.pow(bleg,2))
print("The hypotenuse of a right triangle with leg lengths",int(aleg), "and",int(bleg), "is {:0.4}".format(hypotenuse)+".")