"""
Intermediate Problem:  Create a program that outputs the amount of hours,
and the both the remaining minutes and seconds from a given number of seconds.

File Name: time_conversion.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
