"""
Intermediate Problem:  Create a program that outputs the amount of retroactive pay due
                       the employee, the new annual salary, and the new monthly salary.

File Name: back_pay.py
Name:      ?
Course:    CPTR 141
"""

RAISE = 0.076

# Your code goes here
