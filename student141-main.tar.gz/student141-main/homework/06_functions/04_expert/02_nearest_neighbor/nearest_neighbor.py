"""
Expert Problem:  A Nearest Neighbor implementation using two functions

File Name: nearest_neighbor.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
import math


def get_distance(p1, p2):
    chanagex = math.pow((p2[0]-p1[0]), 2)
    chanagey = math.pow((p2[1]-p1[1]), 2)
    distance = math.sqrt(chanagex + chanagey)
    return distance


def nearest_neighbor(p, data):
    temp = []
    for i in range(len(data)):
        temp.append(get_distance(p, data[i][0:2]))
    minum_num = min(temp)
    index_num = temp.index(minum_num)
    color = data[index_num][2]
    return color
