"""
Expert Problem:  A library of functions for lists of numbers

File Name: list_functions.py
Name:      ?
Course:    CPTR 141
"""


# Your code goes here
def same_sign(my_list):
    same = False
    if all((x > 0 for x in my_list)):
        same = True
    if all((x < 0 for x in my_list)):
        same = True
    if all((x == 0 for x in my_list)):
        same = True
    return same


def find_indexes(a, my_list):
    index1 = []
    index_num = 0
    for i in my_list:
        if i == a:
            index1.append(index_num)
        index_num += 1
    return index1

def count_divisible(c, my_list):
    mood_count = 0
    for j in my_list:
        if (j % c) == 0:
            mood_count += 1
    return mood_count
