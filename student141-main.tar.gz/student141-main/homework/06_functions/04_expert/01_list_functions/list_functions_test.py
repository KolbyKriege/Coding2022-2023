"""
Implement your function in the file list_functions.py

Use this file to test your function.  The code you write in this file will
not be graded.
"""


import list_functions

my_list = [4, 6, 8, 6]
print(list_functions.same_sign(my_list))
print(list_functions.find_indexes(6, my_list))
print(list_functions.count_divisible(3, my_list))
