"""
Intermediate Problem:  Create a function that takes a list of keys and a list of values
                       of the same length and builds a dictionary.

File Name: build_dictionary.py
Name:      ?
Course:    CPTR 141
"""


# your code goes here
