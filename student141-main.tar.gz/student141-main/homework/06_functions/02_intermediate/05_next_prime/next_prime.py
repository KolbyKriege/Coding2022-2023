"""
Intermediate Problem: Create two functions to assist with a program to find the
                      next prime after an entered integer.

File Name: next_prime.py
Name:      ?
Course:    CPTR 141
"""


# Your code goes here
