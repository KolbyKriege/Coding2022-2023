"""
Intermediate Problem: Create a functions that search a dictionary of name/salary key/value
                      pairs and returns the names of employees with salaries matching
                      various criteria.

File Name: employee_dictionary.py
Name:      ?
Course:    CPTR 141
"""


# Your code goes here
