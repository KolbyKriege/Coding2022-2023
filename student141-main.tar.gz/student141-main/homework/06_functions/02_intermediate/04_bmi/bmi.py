"""
Intermediate Problem: Create a functions that compute and classify the BMI.

File Name: bmi.py
Name:      ?
Course:    CPTR 141
"""


# Your code goes here
