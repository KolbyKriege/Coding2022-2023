"""
Intermediate Problem: Create a functions that returns True if a given
                      string is a valid hex color code.

File Name: hex_color.py
Name:      ?
Course:    CPTR 141
"""


# Your code goes here
def valid_hex_color (hex):
    vaild_chara = ['#','a','b','c','d','e','f','1','2','3','4','5','6','7','8','9','0']
    valid_hex = False
    if hex[0] == '#':
        if (4 == len(hex)) or (7 == len(hex)):
            for i in range(len(hex)):
                hex = hex.lower()
                if hex[i] in vaild_chara:
                    valid_hex = True
                else:
                    valid_hex = False
                    break
    return valid_hex