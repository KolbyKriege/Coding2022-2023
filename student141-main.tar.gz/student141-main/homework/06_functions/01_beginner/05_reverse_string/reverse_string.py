"""
Beginner Problem:  Create a function that returns the reverse of a provided string.

File Name: reverse_string.py
Name:      ?
Course:    CPTR 141
"""


# Your code goes here
