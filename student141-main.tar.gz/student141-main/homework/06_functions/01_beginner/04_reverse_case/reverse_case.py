"""
Beginner Problem:  Write a function that reverses the case of any letters
                   in a provided string and returns the result.

File Name: reverse_case.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
