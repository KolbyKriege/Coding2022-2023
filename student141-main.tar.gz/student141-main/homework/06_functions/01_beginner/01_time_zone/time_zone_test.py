"""
Implement your function in the file time_zone.py

Use this file to test your function.  The code you write in this file will
not be graded.
"""

import time_zone

print("In Mountain Time it is:", time_zone.tz_convert("14:52:00", "MT"))
