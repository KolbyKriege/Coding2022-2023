"""
Beginner Problem: Create a function that converts time from the pacific
                  time zone to the eastern, central, or mountain time zone.

File Name: time_zone.py
Name:      ?
Course:    CPTR 141
"""

# Define Your Function Here
