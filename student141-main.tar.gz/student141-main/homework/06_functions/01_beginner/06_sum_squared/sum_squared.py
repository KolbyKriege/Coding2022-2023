"""
Beginner Problem: Create a function that squares each number in a list
                  and returns the sum of those squared numbers.

File Name: sum_squared.py
Name:      ?
Course:    CPTR 141
"""


# Your code goes here
