"""
Beginner Problem: Write a function that returns True if a given value is
                  in a provided interval.

File Name: in_range.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
