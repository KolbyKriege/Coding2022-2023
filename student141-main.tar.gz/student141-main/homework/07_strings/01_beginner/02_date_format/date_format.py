"""
Beginner Problem: Write a function that returns one of two formatted versions
                  of a provided day, month, and year.

File Name: date_format.py
Name:      ?
Course:    CPTR 141
"""


# Define your function here
def date_format (day,month, year, type1):
    
    final = ''
    if not( 1 <= month <= 12) or not(1 <= day <= 31) or not(year>0):
        final =  False
    else:
        day = str(day)
        month = str(month)
        year = str(year) 
        if type1 == 1:
            final = '/'.join([f'{month:>02}',f'{day:>02}',f'{year:>02}'])
        if type1 == 2:
            final = '-'.join([f'{year:>02}',f'{month:>02}',f'{day:>02}'])
    return final