"""
Beginner Problem: Write a function to returns the sum of
                  unicode code points for characters in a string.

File Name: code_sum.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
def code_sum (string):
    points = 0
    for i in range(len(string)):
        if string[i].isalpha:
            points += ord(string[i])
        elif i is string.isdigit:
            temp = int(i)
            points += temp
    return points
