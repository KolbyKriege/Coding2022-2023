"""
Implement your function in the file code_sum.py

Use this file to test your function. The code you write in this file will
not be graded.
"""


import code_sum

my_str = "abc123"
print(
    'The sum of the codepoints in "{}" is {}.'.format(my_str, code_sum.code_sum(my_str))
)
