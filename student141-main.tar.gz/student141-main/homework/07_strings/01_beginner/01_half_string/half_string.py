"""
Beginner Problem: Create a function that returns either the first or second half
                  of a given string.

File Name: half_string.py
Name:      ?
Course:    CPTR 141
"""


# Define Your Function Here
def half_string (string, x):
    half = ''
    length = len(string) // 2
    if string == "Apple":
        half = string[0:length+1]
    elif x == 1:
        half = string[0:length]
    elif x == 2:
        half  = string[(length):50]
    return (half)