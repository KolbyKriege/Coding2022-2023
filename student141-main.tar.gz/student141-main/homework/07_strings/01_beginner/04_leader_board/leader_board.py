"""
Beginner Problem:  Create a function that formats and outputs a leaderboard.

File Name: leader_board.py
Name:      ?
Course:    CPTR 141
"""


# Write your function here
