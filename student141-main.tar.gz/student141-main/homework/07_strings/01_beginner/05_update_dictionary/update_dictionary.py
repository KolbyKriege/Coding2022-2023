"""
Beginner Problem:  Update a dictionary by changing one value to another

File Name: update_dictionary.py
Name:      ?
Course:    CPTR 141
"""

# Write your function here
