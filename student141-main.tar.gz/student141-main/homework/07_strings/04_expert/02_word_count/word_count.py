"""
Expert Problem:  Create functions to compute and display summary statistics
                 about the number of words per sentence in a given string.

File Name: word_count.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
