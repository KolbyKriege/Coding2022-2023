"""
Expert Problem:  Create a function that translates a string into pig latin.

File Name: pig_latin.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
def to_pig (my_str):
    vowel = ['a','e','i','o','u','A','E','I','O','U']
    new_string = []
    new_string = new_string
    my_str = str(my_str)
    split_str = my_str.split()
    for i in range(len(split_str)):
        test = False
        frist_lett = split_str[i][0]
        if not(frist_lett in vowel) and (len(split_str[i])>2):
            new_word = split_str[i]
            new_word = new_word.find[vowel]            




            test = True
            print(new_word)
    return test