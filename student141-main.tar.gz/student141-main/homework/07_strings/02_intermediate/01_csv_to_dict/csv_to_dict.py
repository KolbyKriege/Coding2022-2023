"""
Intermediate Problem:  Create a function that transforms a list of CSV strings
                       into a dictionary.

File Name: csv_to_dict.py
Name:      ?
Course:    CPTR 141
"""

# Write your function here
def csv_to_dict (string):
    final= {}
    for j in range(len(string)):
        total = 0
        cont_aver = 1
        name = []
        print(j)
        for i in range(len(string[j])):
            temp = string[j].split(',')
            print(temp)
        #     if temp[i].isdigit():
        #         total += int(temp[i])
        #         cont_aver += 1
        #         print("test")
        #     if temp[i].isalpha():
        #         if temp[i].isupper():
        #             name.append(' ')
        #         name.append(temp[i])
        #         new_name = ''.join(name)
        # aver_total = total / cont_aver
        # final[new_name] = aver_total

        # print(temp[3])