"""
Intermediate Problem:  Create a function that returns the sum of all single-character
                       numeric digits in a string.

File Name: sum_digits.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
def sum_digits (string):
    total = 0
    for i in string:
        
        if i.isdigit():
            total += int(i)
            
    return total