"""
Intermediate Problem:  Create a program that capitalizes the first letter of each
                       sentence and any consonant that comes immediate after a
                       vowel in a single word.

File Name: capitalization.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
def  capitalization (string):
    vowel = ['a','e','i','o','u','A','E','I','O','U']
    for i in range(len(string)):
        if string[i] in vowel:
            if string.find('.')
            # new_lett = ""
            new_lett = string[i+1].capitalize()
            new_lett = str(new_lett)
            string = string.replace(string[i+1], new_lett)
            print(new_lett)
            print(string)



    #test = 'wrpd'
    #pog = test.capitalize()
    return string