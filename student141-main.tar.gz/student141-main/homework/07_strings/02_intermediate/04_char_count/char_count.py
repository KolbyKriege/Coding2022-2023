"""
Intermediate Problem:  Create a program that counts the number of occurrences of each
                       character in a string and returns that info as a dictionary.

File Name: char_count.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
def char_count (string):
    # alphbet = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
    final = {}
    string = string.lower()
    for j in string:
        letter_count = 0
        letter_count = string.count(j)
        if letter_count != 0:
            final[j] = letter_count
    return final

