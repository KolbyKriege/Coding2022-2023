"""
Intermediate Problem:  Create a function that prints out a formatted itemized invoice of
                       groceries and their costs.

File Name: gorcery_table.py
Name:      ?
Course:    CPTR 141
"""

# Write your function here
def invoice (get,prices):
    prices_list = prices.keys()
    for j in prices_list:
        count = 0
        count = get.count(j)
        count