"""
Intermediate Problem:  Create a program that outputs three items from the user in numerical bullet points

File Name: list_three_items.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
#proms user to enter items
print("Enter three things in your room.")
item1= input("Item one: ")
item2= input("Item two: ")
item3= input("Item three: ")
print()
#prints out the inputed items
print("1.",item1)
print("2.",item2)
print("3.",item3)