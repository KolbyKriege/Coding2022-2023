"""
Intermediate Problem:  Create a program that outputs a famous quote by pyhsicist Albert Einstein (1879-1955)

File Name: albert_einstein_quote.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
#prints outs quote
print("Computer are incredibly fast, accurate, and stupid;")
print("  humans are incredibly slow, inaccurate, and brilliant;")
print("    together they are powerful beyond imagination.")
print()
print("- Albert Einstein (1879-1955)")