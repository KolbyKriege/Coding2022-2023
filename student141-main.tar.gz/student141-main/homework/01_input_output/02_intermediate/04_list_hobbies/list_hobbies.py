"""
Intermediate Problem:  Create a program that outputs three hobbies from the user in a bullet point fashion

File Name: list_hobbies.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
print("What are your top three hobbies you like to do in your free time?")
hobb1 = input("Hobby one: ")
hobb2 = input("Hobby two: ")
hobb3 = input("Hobby three: ")
print()

print("Top Three Hobbies")
print("   -",hobb1)
print("   -",hobb2)
print("   -",hobb3)
