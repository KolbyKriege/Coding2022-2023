"""
Intermediate Problem:  Create a program that outputs a famous quote from the author Ada Lovelace (1815-1852)

File Name: ada_lovelace_quote.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
