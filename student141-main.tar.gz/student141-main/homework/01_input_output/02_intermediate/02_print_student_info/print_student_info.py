"""
Intermediate Problem:  Create a program that outputs the user name, class position, and school

File Name: print_student_info.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
print("What is your name?")
name = input()
print("What is your current class standing?")
stand= input()
print("What school are you attending currently?")
school = input()
print()

print("Hi my name is",name+", and I am a",stand,"at",school+".")