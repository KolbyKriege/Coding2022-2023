"""
Expert Problem:  A mad-libs introduction to Old MacDonald

File Name: old_macdonald.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
#proms user to enter in words for mad lib
adjec1=input("Enter an adjective: ")
noun1 = input("Enter a noun: ")
animal1 = input("Enter an animal: ")
sound1 = input("Enter a sound: ")
print()
#prints out mad lib
print(adjec1,"MacDonald had a", noun1+", E-I-E-I-O")
print("and on that",noun1, "he had a",animal1+", E-I-E-I-O")
print("with a",sound1,sound1,"here")
print("and a",sound1,sound1,"there,")
print("here a",sound1+", there a",sound1)
print("everywhere a",sound1,sound1+",")
print(adjec1,"MacDonald had a",noun1+", E-I-E-I-O.")