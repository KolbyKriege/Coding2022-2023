"""
Expert Problem:  A mad-libs introduction to Row Row Your Boat

File Name: row_your_boat.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here

# Promites user to enter muiltpule words for mad lib
verb1 = input("Enter a verb: ")
verb2 = input("Enter a second verb: ")
adverb1 = input("Enter a adverb: ")
noun1 = input("Enter a noun: ")
noun2 = input("Enter a second noun: ")
print()
# print out the finish product of mad lib
print("Row,", verb1 + ",", verb2, "your boat")
print(adverb1, "down the", noun1)
print("Merrily, merrily, merrily, merrily")
print("Life is but a", noun2)
