"""
Beginner Problem:  Create a program that outputs a double line quote

File Name: alan_turing_quote.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
