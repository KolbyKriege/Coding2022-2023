"""
Beginner Problem:  Create a program that outputs "Hello World!"

File Name: hello_world.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
# Print Hello World!
print("Hello World!")
