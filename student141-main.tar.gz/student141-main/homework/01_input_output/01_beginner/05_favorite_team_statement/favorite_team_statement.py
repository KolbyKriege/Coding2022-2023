"""
Beginner Problem:  Create a program that outputs the user favorite sports team

File Name: favorite_team_statement.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
