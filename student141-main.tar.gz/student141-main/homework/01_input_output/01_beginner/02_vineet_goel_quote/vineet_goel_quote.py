"""
Beginner Problem:  Create a program that outputs a single line quote

File Name: vineet_goel_quote.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
