"""
Beginner Problem:  Create a program that outputs the name of the user pet three times

File Name: pet_name_repeat.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
