"""
Beginner Problem:  Create a program that outputs the user favorite color

File Name: favorite_color_statement.py
Name:      ?
Course:    CPTR 141
"""

# Your code goes here
