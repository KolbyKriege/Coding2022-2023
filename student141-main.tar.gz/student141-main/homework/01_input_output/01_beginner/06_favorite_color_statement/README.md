# CPTR 141: Objective #1 (1 point)

## Problem Overview

Your task in this homework assignment is to write a program that outputs a statement about the user's favorite color.  

## Solution Specifications

Your solution to this problem must meet the following criteria.

1. You must use `print` to display output.

2. You must format your code using the *Format Document* command in your development environment.

3. You **must** produce output exactly as shown below, given that the user inputs the color "Blue".

```text
What is your favorite color?
Blue

My favorite color is Blue too!
```

## Grade Specification

You will earn **one point** for completion of this homework problem once your solution passes all Submitty tests (indicated by all green bars).
